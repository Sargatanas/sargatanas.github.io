﻿/**
 Задание 1
 **/

function Ex1() {
    var n = document.getElementById('n1').value;
    var min = 101;
    var count = 0;
    var string = '';

    var i, temp;
    for (i=1; i<=n; i++) {
        temp = Math.floor(Math.random() * 10);
        string = string + ' &#8196; ' + temp;
        if (temp < min) {
            min = temp;
            count = 1
        }
        else {
            if (temp == min) count++;
        }
    }

    if (n < 1) min = 'не существует';

    document.getElementById('output1').innerHTML = string;
    document.getElementById('min1').innerHTML = String(min);
    document.getElementById('count1').innerHTML = String(count);
}

function Ex2() {
    var n = document.getElementById('n2').value;
    var cont, n1;
    var string = '';

    n1 = n;
    cont = 0;
    while (n1 > 0) {
        cont += n1 % 10;
        n1 = Math.floor(n1 / 10);
    }

    var i, sum;
    for (i=1; i<n; i++) {
        n1 = i;
        sum = 0;
        while (n1 > 0) {
            sum += n1 % 10;
            n1 = Math.floor(n1 / 10);
        }
        if (sum == cont) {
            string = string + ' &#8196; ' + i;
        }
    }

    if (string == '') string = 'не существует';

    document.getElementById('count2').innerHTML = String(n);
    document.getElementById('output2').innerHTML = string;
}

function CountDay(y, d, m) {
    var count, i;
    count = 0;
    for (i=1; i < m; i++) {
        switch (i) {
            case 1: count += 31; break;
            case 2: if (y % 4 == 0) {
                        count += 29;
                    }
                    else {
                        count += 28;
                    } break;
            case 3: count =+ 31; break;
            case 4: count =+ 30; break;
            case 5: count =+ 31; break;
            case 6: count =+ 30; break;
            case 7: count =+ 31; break;
            case 8: count =+ 31; break;
            case 9: count =+30; break;
            case 10: count =+ 31; break;
            case 11: count =+ 30; break;
        }
    }
    count += d;
    if (y % 4 == 0) {
        count = 365 - count}
    else {
        count = 366 - count}
    return count;
}

function Ex3() {
    var d, day, month, year;
    d = document.getElementById('n3').value;
    year = d.getFullYear();
    month = d.getMonth();
    day = d.getDate();
    document.getElementById('output3').innerHTML = '1';
}

function Ex4() {
    var check = document.getElementById('n4').value;
    if (check) {
        window.status = 'Сделайте выбор!';
    }
}
